let express = require("express");
const bodyParser = require("body-parser");
const monoose = require('mongoose');

const userRoutes = require("./router/userRoute");
var ejs = require("ejs");

const app = express();
const DB = 'mongodb+srv://pavan:pavan123@cluster0.p7rve.mongodb.net/usersdb?retryWrites=true&w=majority';

monoose.connect(DB, {
  useNewUrlParser: true,
  useCreateIndex: true,
  useUnifiedTopology: true,
  useFindAndModify:false
}).then(() => {
  console.log(`connection successful`);
}).catch((err) => console.log(`no connection`));

app.use(express.json());
app.use(express.urlencoded());

const dbConnection = require("./models/config");
app.use("/uploads", express.static("uploads"));

app.set("view engine", "ejs");

app.get("/", (req, res) => {
  res.render("index.ejs");
});

//routes
app.use("/student", userRoutes);

app.listen(3000, (req, res) => {
  console.log("server is up and running");
});
