const db = require("../models/config");

exports.register = async (req, res) => {
  console.log(req.body, req.file);
  const { username, gender, phone } = req.body;
  let profile;
  if (req.file) {
    profile = `http://localhost:3000/${req.file.path}`;
  } else {
    profile = "";
  }
  let course = req.body.course != "Course" ? req.body.course : "N/A";

  await db.User.create({
    username: username,
    course: course,
    gender: gender,
    phone: phone,
    image: profile,
  });

  return res.render("successfull.ejs");
};

exports.allstudents = async (req, res) => {
  let allStudents = await db.User.find({});
  res.render("users.ejs", { allStudents });
};

exports.Update = async (req, res) => {
  const { username, gender, phone } = req.body;
  let course = req.body.course != "Course" ? req.body.course : "N/A";

  let update = await db.User.findByIdAndUpdate(req.params.id, {
    $set: { username: username, gender: gender, phone: phone, course: course },
  });
  update.save();
  res.redirect("/student/all");
};

exports.Delete = async (req, res) => {
  console.log("here");
  console.log(req.params.id);
  await db.User.findByIdAndRemove(req.params.id);
  res.redirect("/student/all");
};
