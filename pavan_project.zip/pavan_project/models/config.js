var mongoose = require("mongoose");
mongoose.Promise = Promise;
mongoose
  .connect("mongodb://localhost:27017/usersdb", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("db connection successful");
  })
  .catch((err) => {
    console.log("db connection fail", err);
  });

exports.User = require("./userModel");
